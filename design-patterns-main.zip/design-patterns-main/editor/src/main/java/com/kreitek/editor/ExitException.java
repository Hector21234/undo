package com.kreitek.editor;

public class ExitException extends Throwable {
}
