# Design Patterns examples

## Introduction

This is a collection of samples of design patterns for training purposes.

## Code examples

- Pets. Implements the Singleton pattern.
- State. Implements the State pattern.

## Code for exercices

- Editor. Implements a basic console text editor.
